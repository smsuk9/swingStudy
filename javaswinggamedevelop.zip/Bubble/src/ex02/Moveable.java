package ex02;

public interface Moveable {

	public abstract void left();
	public abstract void right();
	public abstract void up();
	public abstract void down();
}
