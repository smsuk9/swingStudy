package ex02;

public class index {

	public static void main(String[] args) {

		new BubbleFrame();

	}

}
